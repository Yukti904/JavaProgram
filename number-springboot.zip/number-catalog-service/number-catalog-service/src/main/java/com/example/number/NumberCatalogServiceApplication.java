package com.example.number;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NumberCatalogServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(NumberCatalogServiceApplication.class, args);
	}

}
